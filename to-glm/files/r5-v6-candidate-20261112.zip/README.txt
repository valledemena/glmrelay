R5 � CANDIDATO v6 DEEP GATE (STOP C/D)
v6 sha256: 5a48cb189c33b7a4e81bed65263caf30d51272265a62c36e7eaf21afa4a6dea4
base: v5 original ba433297...
diff: +44/-14, solo W11
4/4 E/P exacto: 50/50, 48/50, 48/48, 44/48
C/D: W11 PASS; total v6 39/40 y 45/46 por W10 acumulativo (highp entra con P)
smoketest 4/4: 2.00 PASS; 2.01 FAIL; DEEP ausente FAIL; parity_tol=3.0 FAIL
No push, no PR. Se solicita ruling sobre el anexo C/D.
