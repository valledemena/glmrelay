# R5 — v6 DEEP GATE — REGRESIÓN Y STOP C/D — 2026-11-12

**Candidato:** `docs/r4/tools/R4_DISPLAY_CHECK_v6.py`  
**sha256:** `5a48cb189c33b7a4e81bed65263caf30d51272265a62c36e7eaf21afa4a6dea4`  
**Base:** v5 original `ba433297…`  
**Diff:** 1 fichero, **+44/−14** (`work/r5-v5-v6.diff`)  
**Estado:** implementado en local; **no push, no PR**. STOP por desvío del anexo C/D.

---

## 1. Qué se implementó

Solo W11:

- `PARITY_TOL = 2.0` fijada en el instrumento.
- W11 exige THIN y DEEP; DEEP `max|Δ_DEEP| <= 2.0`.
- Si falta DEEP o el comp declara `parity_tol != 2.0`, W11 falla cerrado.
- E2, P0, P1, el medidor y `app/src/main` no se tocan.
- `py_compile` OK.

## 2. Regresión 4/4 (E/P): exacta

| Ref | Selector | v5 | v6 | Resultado |
|---|---|---|---|---|
| `24595b1` | E | 50/50 | **50/50** | FIRME |
| `e23b47e` | E | 48/50 | **48/50** | S3/S4 por merge |
| `a483f48` | P | 48/48 | **48/48** | FIRME |
| `e23b47e` | P | 44/48 | **44/48** | S3/S4/S6/P0 por merge |

W11 PASS en los cuatro. Sin cambios fuera de W11.

## 3. Anexo C/D: desvío por W10

| Ref | Selector | v3 histórico | v6 | W11 | W10 |
|---|---|---|---|---|---|
| `53a6df7` | C | 40/40 | **39/40** | **PASS** | FAIL |
| `1ec6f36` | D | 46/46 | **45/46** | **PASS** | FAIL |

El único FAIL es **W10**: `AtmoShaderSource.kt` no declara `precision highp`
en C/D porque **highp entra con P**, después de C/D. W10 es acumulativo en
v5/v6; los 40/40 y 46/46 históricos son de **v3**, no de v5/v6. Mezclar esos
totales con v6 era un error del plan rev.3, no un fallo del gate DEEP.

El gate nuevo **W11 pasa en C y D** con DEEP 0.64; no voltea esos puntos.
Los totales v6 39/40 y 45/46 son los esperados por la acumulación de W10.

## 4. Smoketest 4/4

| Fixture | W11 | Total |
|---|---|---|
| DEEP 2.00 | PASS | 50/50 |
| DEEP 2.01 | FAIL | 49/50 |
| DEEP ausente | FAIL | 49/50 |
| `parity_tol=3.0` | FAIL | 49/50 |

## 5. Propuesta de corrección (no aplicar en caliente)

**A (recomendada):** el anexo C/D se define como **W11-only**:

- C `53a6df7`: W11 PASS; total v6 39/40 con W10 FAIL declarado.
- D `1ec6f36`: W11 PASS; total v6 45/46 con W10 FAIL declarado.
- Regresión de aceptación: **4/4 E/P + 2/2 W11 C/D**.
- Los 40/40 y 46/46 quedan como FIRME histórico v3, no como total v6.

**B:** añadir un modo `--skip-w10` para refs históricos; no recomendado
(complejidad y riesgo de enmascarar).

**C:** usar v3 para C/D; no prueba el gate nuevo.

## 6. Estado

No se ha hecho push ni PR. `main` sigue en `e23b47e`. La rama local
`feat/r5-deep-gate` tiene el v6 sin commitear. Se necesita el ruling de GLM
sobre el anexo C/D antes de continuar.
