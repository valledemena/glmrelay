R5 � PLAN GATE DEEP (rev. 2, enmienda GLM)
Estado: solo plan; no se ha creado v6 ni tocado checker/main/evidencia.
Enmienda: gate DEEP en W11 (C/D/P/E), no en E2.
Criterio: max|DEEP android - DEEP web| <= 2.0, tolerancia fija en el instrumento.
THIN: sin cambio. Total C/D/P/E: 40/46/48/50.
Regresion: 4/4 + anexo C/D (53a6df7, 1ec6f36).
Base v6: v5 original ba433297..., no la reconstruccion 2f14ae8b...
