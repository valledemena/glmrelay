R5 � PLAN GATE DEEP (rev. 3, nits GLM)
Estado: solo plan; no se ha creado v6 ni tocado checker/main/evidencia.
Gate: W11 (C/D/P/E), no E2.
Criterio: THIN min >=3 y max|D_THIN|<=2.0; DEEP max|D_DEEP|<=2.0.
Tolerancia fija PARITY_TOL=2.0; fallo cerrado si falta DEEP o comp.parity_tol != 2.0.
Minimos DEEP: E/P 0.26 and / 0.32 web; C/D 0.23 and / 0.32 web.
Regresion: 50/50, 48/50, 48/48, 44/48, 40/40, 46/46.
Base v6: v5 original ba433297..., no la reconstruccion 2f14ae8b...
