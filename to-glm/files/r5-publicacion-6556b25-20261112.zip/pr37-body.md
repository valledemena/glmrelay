## R5 — gate DEEP en W11 (checker v6)

Añade el instrumento `docs/r4/tools/R4_DISPLAY_CHECK_v6.py`, derivado del **v5
original autenticado** (`ba433297…`) con un delta mínimo de **+44/−14** confinado
a W11. No toca código de la app: `app/src/main` queda intacto.

**sha256 del instrumento: `5a48cb189c33b7a4e81bed65263caf30d51272265a62c36e7eaf21afa4a6dea4`**
(pre-registro vinculante: el blob commiteado es byte-idéntico a ese fichero).

### Qué cambia

- `PARITY_TOL = 2.0` fijada en el instrumento, no leída de la evidencia.
- W11 gatea también **DEEP**: ambas capturas deben traer
  `delta_B_deep_by_sector` (10 sectores) y `max|Δ_DEEP| <= 2.0`.
- **Fallo cerrado**: si el comp declara `parity_tol != 2.0`, W11 falla.
- Texto del check actualizado.
- E2 (solo THIN), P0, P1, S*, W1..W10 y `docs/r4/tools/w11-metric.py` **sin
  cambios**.

### Regresión 6/6 (reproducida por OpenCode y por GLM en clones separados)

Cada fila con su base exacta (el padre de cada corte, no el main de hoy):

| ref | sel | base (`origin/main` en su día) | total | W11 |
|---|---|---|---|---|
| `a483f48` | P | `bfea5d8` | **48/48 FIRME** | PASS |
| `24595b1` | E | `75366b2` | **50/50 FIRME** | PASS |
| `e23b47e` | E | `e23b47e` | 48/50 (S3/S4 por diseño) | PASS |
| `e23b47e` | P | `e23b47e` | 44/48 (S3/S4/S6/P0 por diseño) | PASS |
| `53a6df7` | C | `9550914` | 39/40 (W10) | PASS |
| `1ec6f36` | D | `cebd6ef` | 45/46 (W10) | PASS |

**v6 ≡ v5 en los seis cortes**: el v6 no cambia ningún total.

### Anexo C/D

Los 40/40 y 46/46 históricos son totales de **v3**, donde W10 era un grep
**global** de `precision highp` en `app/src/main` y pasaba por las declaraciones
que trajeron B/C mientras la atmósfera seguía en `mediump`. **v4** acotó W10 al
pase de atmósfera (`AtmoShaderSource.kt`), y por eso C y D caen exactamente 1
punto con v5/v6. Medido: v5 en C = 39/40, en D = 45/46, idéntico a v6. El fallo
es correcto: `git show` confirma `mediump` en C/D y `highp` desde P.

### Smoketest

`2.00 → PASS` (límite inclusivo) · `2.01 → FAIL` · DEEP ausente → FAIL cerrado ·
`parity_tol=3.0` → FAIL cerrado · DEEP 2.05 → FAIL.

### Dictamen

GLM: `DICTAMEN-R5-V6-DEEP-GATE-5a48cb18-ANEXO-GO-GLM-20261112` — anexo C/D
aprobado re-basado en v5, GO para publicar el `5a48cb18…` tal cual, sin ajustes
previos al commit.

Evidencia de la revisión independiente:
`INTERCAMBIO/work/revision-opencode-r5-v6-20261112.txt`.
