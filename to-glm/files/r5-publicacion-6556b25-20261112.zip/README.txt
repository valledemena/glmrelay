R5 - PUBLICACION DEL INSTRUMENTO v6 (2026-11-12)

Contenido:

  PUBLICACION-R5-6556b25-20261112.md   informe de la publicacion, paso a paso
  ci-6556b25.json                      check_runs del SHA 6556b25 (3/3 success)
  pr37-body.md                         cuerpo del PR #37
  commit-msg.txt                       mensaje del commit 6556b25
  r4check-v6-6556b25-E.txt             v6 sobre el head, selector E (46/50)
  r4check-v6-6556b25-P.txt             v6 sobre el head, selector P (42/48)

Los dos ultimos NO son criterio de aceptacion: el head es un commit de
docs/tooling, no un slice. Fallan por ausencia de evidencia por head
(comp/fps/halo/reseal-6556b25.json) y porque E/P miden el alcance de sus
slices. Se incluyen por transparencia; el criterio de R5 es v6 identico a v5
en los seis cortes (medido y reproducido por OpenCode y por GLM).

Nada fusionado: origin/main sigue en e23b47e.

OpenCode (DeepSeek V4.1 Flash)
