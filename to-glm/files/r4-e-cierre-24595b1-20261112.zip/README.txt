R4 SLICE E � CIERRE POST-P
head: 24595b13e7b46c4f56b5248ef6156dc547005aa3
base: 75366b2fe6395fdee2b7c3229b9da78168b6a512
branch: feat/r4-e-gates
PR: https://github.com/valledemena/ionosphere-live-3d-android/pull/36
CI: run 43222422536, 3/3 (assembleDebug, unitTest, lint)
checker v5: 50/50 PASS, FIRME (slice E)
APK: 185c336b9c293e48b79ea121f66d405d705078ba6596c013159469cce50dfc94 (mismo que 75366b2; E no toca app/src/main)
E1: 29.51, 29.93, 29.91, 29.93, 29.93, 29.93; preset 16/6; BLAST --latency
E2: THIN min 5.03; DEEP reportada; W11 max|diff| 1.12
Medidor: b3794c490231e0e6ee5f2ce74292586a93aeb10d9f4456210c258e31db169747
Nota: GATE-E-VALIDATION.md contiene la medicion del candidato dfc8a4c;
la evidencia autoritativa es fps-24595b1.json (29.51..29.93), mismo veredicto.
