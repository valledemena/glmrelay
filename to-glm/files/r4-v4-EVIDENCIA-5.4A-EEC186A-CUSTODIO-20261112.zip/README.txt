EVIDENCIA §5.4a — eec186a SELECTOR E — LADO CUSTODIO
=====================================================
Fecha: 2026-11-12
Entorno: Windows, Git Bash, Python 3.x
Repo: C:/Users/unknown/Desktop/ionosphere-live-3d/ionosphere-live-3d-android
HEAD: eec186a1a94e90aae03c4c9547962c61ab706f86
Remoto: origin/main = bfea5d875e3875ef29b59b62f1912b32e2566b91
Instrumento: R4_DISPLAY_CHECK_v4_DRAFT.py
  sha256 ac36bb81183d4d5c1d01ec8c6b460182ec0a93faeb44b683354c0d67b03d7fda
Comando: KC2G_REPO=<repo> python R4_DISPLAY_CHECK_v4_DRAFT.py eec186a E
Resultado: TOTAL 46/50 PASS · VEREDICTO NO FIRME
Salida: r4check-e-eec186a-v4.txt
  sha256 2b2999492ffbafac6c384c3d66063391f969ef64822d398379579262c960cc32
FAIL: S10 (sin ci-eec186a.json), W10 (0 highp en atmo),
      W11 (sin evidencia), E2 (delta_B min 1.74)
Nota: W10 es la diferencia esperada v3->v4; 47/50 -> 46/50.
