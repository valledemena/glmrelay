# PROPUESTA R4.4 - MODELO NE(H) Y VOLUMEN PURO

De: Buffy (lado implementador; relay Deepseek)
Para: David y GLM
Fecha: 2026-11-16
Base: `main` `84d4e9e` (PR #47 mergeado)
Referencias: `docs/r4/PLAN-R4-TIEMPO-PROFUNDIDAD.md` secciones 4.4, R4.4 y G7; `RELEVO-OPENCODE-R4-20261114.md`; pin web `8cdc334`.
Estado: **propuesta de alcance**; no hay codigo escrito ni rama creada. Las tres decisiones de frontera (D1-D3) estan en la seccion 8 y se detallan para GLM en `PARA-GLM-REVISION-PROPUESTA-R4.4-20261116.md`.

---

## 1. Objetivo

Portar a Kotlin puro el modelo de densidad electronica Ne(h) y el constructor del volumen que hoy existen en el pin web `8cdc334`:

- `src/lib/iono/densityVolume.ts`
- `src/lib/iono/layerProfile.ts`

El resultado debe ser una rejilla de densidad reproducible, sin GL, sin UI y sin red. R4.4 termina cuando una rejilla de prueba tiene las mismas dimensiones, indices, valores, capas y bordes que el oraculo.

No se abre la cortina, el raymarch ni ningun toggle visual. Eso es R4.5/R4.6.

---

## 2. Alcance propuesto

### 2.1 Dentro de R4.4

Ficheros nuevos, bajo `app/src/main/java/com/valledemena/ionosphere/core/iono/`:

1. `DensityVolume.kt`
   - Constantes del volumen.
   - `DensityVolume` (data/layer/valid/timestamp).
   - `volumeIndex`.
   - `volumeAltKm`.
   - `densityDir` (dependencia de D1).
   - `applyDayNight` (D1; version funcional, sin mutar la lista de entrada).

2. `LayerProfile.kt`
   - `FO_TO_NM`.
   - `LayerProfile` y `NeWinner`.
   - `blankProfile`.
   - `sanitizeB0`, `sanitizeB1`.
   - `profileFromFo`.
   - `chapmanAlpha`.
   - `f2FloorKm`.
   - `evalNeTotal`.
   - `normLogNe`.
   - `buildDensityVolume`.

Tests nuevos, bajo `app/src/test/java/com/valledemena/ionosphere/core/iono/`:

3. `DensityVolumeTest.kt`
4. `LayerProfileTest.kt`

No se toca `data/**`, `.github/**`, el checker congelado, `SolarPosition`, `StationHistory` ni ningun fichero de UI/GL.

### 2.2 Fuera de R4.4, por slice

| Funcion / bloque | Slice | Motivo |
|---|---|---|
| `extractPeakGrids` | R4.5 | Alimenta shells/iso-bands, no el builder base |
| `integrateTEC` | R4.8 o HUD posterior | Derivado de consumo, no del contrato G7 |
| `sampleVolume` | R4.6 | Muestreo para raymarch |
| `volumeModeIndex`, `volumeOpacityClamp`, `CHAPMAN_WINNER_COLORS` | R4.6 | Parametros de render |
| `profileGrid.ts` / interpolacion estacion-perfil | R4.5 | Wiring de datos; R4.4 no toca `data/**` |
| Cortina, slerp, iso-bands, toggles | R4.5 | Capa visual |
| Raymarch density/chapman y `atmoQuality` | R4.6 | Shader/GPU |
| NDK-MSIS | R4.7 | ADR y licencia |

Decision de frontera: `applyDayNight` **si** entra en R4.4 porque el builder no atenua E/F1 por si solo y la paridad nocturna del volumen lo exige. `densityDir` entra porque el builder lo usa para `cosChi`.

Aviso de alcance para GLM: el plan R4.4 enumera constantes, layout, curva, normalizacion, `volumeIndex`, `volumeAltKm` y perfil de capas; **no nombra** `applyDayNight`, `densityDir` ni `buildDensityVolume`. El builder se incluye porque el DoD pide una rejilla con valores; `applyDayNight` y `densityDir` son la extension D1. Si GLM los rechaza, R4.4 puede seguir con perfiles ya atenuados y el builder tomando `cosChi` precalculado, pero la paridad nocturna y el test G7.6 se mueven a R4.5. Esa es la decision que se pide, no un hecho consumado.

---

## 3. Contrato numerico

### 3.1 Constantes

| Constante | Valor |
|---|---:|
| `VOL_LON_RES` | 72 |
| `VOL_LAT_RES` | 72 |
| `VOL_ALT_RES` | 48 |
| `VOL_ALT_MIN_KM` | 60 |
| `VOL_ALT_MAX_KM` | 500 |
| `VOL_LOG_MIN` | 8.0 |
| `VOL_LOG_RANGE` | 4.5 |
| `VOL_PEAK_FLOOR` | 8.5 |
| `FO_TO_NM` | 1.24e10 |

### 3.2 Rejilla e indices

- Total de celdas: `72 * 72 * 48 = 248 832`.
- Ultimo indice: `(47*72 + 71)*72 + 71 = 248 831`.
- `volumeIndex(x, y, a, w, h) = (a*h + y)*w + x`.
- `lonIdx 0 = -180`, `latIdx 0 = sur`, `altIdx 0 = 60 km`.
- `data` guarda `log10(Ne)` normalizado en `[0,1]`; `layer` guarda `0=D, 1=E, 2=F1, 3=F2`.

### 3.3 Alturas

```text
h_i = altMin + (altMax - altMin) * (i / (n-1))^1.5
```

Con `n=48`: `h_0 = 60`, `h_47 = 500`, `h_1 = 61.3655446013` km, `h_46 = 486.0324082504` km. La malla es mas densa abajo.

### 3.4 Perfil

- `blankProfile`: `NmE=0, hmE=110, NmF1=0, hmF1=180, NmF2=0, hmF2=300, B0=100, B1=3`, flags falsos.
- `sanitizeB0`: NaN o `<= 0` -> 100; `< 20` -> 20; `> 300` -> 300 (`+Inf` cae en 300).
- `sanitizeB1`: NaN o `<= 0` -> 3; `< 1.7` -> 1.7; `> 4` -> 4 (`+Inf` cae en 4).
- `profileFromFo`: `Nm = 1.24e10 * fo^2`; `hmF1 = hmF2 > 0 ? max(150, 0.8*hmF2) : 180`; B0/B1 saneados solo con F2 valida.
- `applyDayNight`: `e = smoothstep(-0.05, 0.25, dot)`, con `smoothstep(e0,e1,x) = t*t*(3-2*t)` y `t = clamp((x-e0)/(e1-e0), 0, 1)`; multiplica `NmE` y `NmF1`; si `e <= 0`, apaga flags E/F1. Version funcional: devuelve una lista nueva, no muta la de entrada.
- `chapmanAlpha(Nm, hm, H, h) = Nm * exp(0.5*(1 - z - exp(-z)))`, `z=(h-hm)/H`.
- `f2FloorKm` reproduce el barrido entero de 1 km del oraculo, sin aproximar.
- `evalNeTotal` devuelve `NeWinner(ne, winner)` con `winner=-1` si no hay rama; el builder mapea `-1` a `0` en `layer`.

### 3.5 Normalizacion

```text
normLogNe(ne) = clamp((log10(ne) - 8.0) / 4.5, 0.0, 1.0)
```

La guarda es la del oraculo `ne > 0`: `ne <= 0`, NaN y `-Inf` -> `0.0`; `+Inf` -> `1.0` por el clamp. El suelo `VOL_PEAK_FLOOR=8.5` se aplica en el consumidor de picos, no en `normLogNe`.

### 3.6 Direccion de escena

`densityDir` usa la convencion del motor:

```text
phi = radians(90 - lat)
theta = pi - radians(lon)
dir = (sin(phi)*cos(theta), cos(phi), sin(phi)*sin(theta))
```

Pines: `(0,0) -> (-1,0,0)`, `(0,90E) -> (0,0,1)`, polo norte -> `(0,1,0)`, norma 1. Esto evita repetir el bug historico de meridianos rotados 180 grados.

### 3.7 Builder

```kotlin
fun buildDensityVolume(
    profiles: List<LayerProfile>,
    sunDir: DoubleArray,
    flareFactor: Double = 1.0,
    lonRes: Int = VOL_LON_RES,
    latRes: Int = VOL_LAT_RES,
    altRes: Int = VOL_ALT_RES,
    altMinKm: Double = VOL_ALT_MIN_KM,
    altMaxKm: Double = VOL_ALT_MAX_KM,
): DensityVolume
```

- Si `profiles.size != lonRes*latRes`: `valid=false`, arrays del tamano completo, sin excepcion.
- Centros de celda: `lat = -90 + 180*(latIdx+0.5)/latRes`, `lon = -180 + 360*(lonIdx+0.5)/lonRes`.
- `cosChi = dot(densityDir(lat, lon), sunDir)`.
- `applyDayNight` se llama antes del builder; el builder no muta perfiles.
- `data` y `layer` usan `DoubleArray` e `IntArray`; no listas boxeadas por celda.
- El test de indices usa una rejilla 3x2 para que un intercambio `w/h` no quede oculto por una rejilla cuadrada.
- `timestamp` queda en `0` en R4.4; el wiring de R4.5 lo fija con la epoca de escena.

`DensityVolume` propuesto:

```kotlin
data class DensityVolume(
    val lonRes: Int,
    val latRes: Int,
    val altRes: Int,
    val altMinKm: Double,
    val altMaxKm: Double,
    val data: DoubleArray,   // log10(Ne) normalizado 0..1
    val layer: IntArray,     // 0=D, 1=E, 2=F1, 3=F2
    val valid: Boolean,
    val timestamp: Long,
)
```

---

## 4. Criterios de aceptacion (G7)

### 4.1 Pines exactos

Los IDs `G7.1`-`G7.12` son de esta propuesta; el plan solo define `G7` por contenido (`72x72x48`, alturas, rango log, indice, capas, bordes). No se presentan como numeracion oficial del plan.

| ID | Criterio | Evidencia |
|---|---|---|
| G7.1 | 72 x 72 x 48; 60..500; log 8..12.5; suelo 8.5 | test de constantes |
| G7.2 | `volumeIndex` reproduce `(a*h+y)*w+x` en una rejilla NO cuadrada (3x2x4) y en los cuatro bordes | test de indices |
| G7.3 | `volumeAltKm`: extremos, `n<=1`, monotonica, paso superior > paso inferior | test de curva |
| G7.4 | `normLogNe`: 8->0, 12.5->1, clamp, `<=0`/NaN/-Inf->0, `+Inf`->1 | test de normalizacion |
| G7.5 | `densityDir` con los tres pines y norma 1 | test de marco |
| G7.6 | `applyDayNight`: subsolar intacto, antisolar apaga E/F1, `dot=0 -> 2/27`, rejilla invalida no-op | test dia/noche |
| G7.7 | `profileFromFo(4,3,7,300,0,1)`: `NmE=1.984e11`, `NmF1=1.116e11`, `NmF2=6.076e11`, `hmF1=240`, `B0=100`, `B1=1.7` | test de perfil |
| G7.8 | `f2FloorKm`: 110, -1, 167, 145, 155, 136; continuidad B0 +-2 <= 15 km | test de suelo |
| G7.9 | winners D/E/F1/F2 en 75/110/200/300; noche F2; perfil vacio `{0,-1}`; invariante contra un max() de referencia | test de ganadores |
| G7.10 | builder 3x2x4: `data`/`layer` completos, valores contra `evalNeTotal` directo, memo invisible | test de builder |
| G7.11 | bordes/huecos: perfil vacio -> dato 0, capa 0; sin F2 -> sin rama F2; sin E -> sin rama E | test de bordes |
| G7.12 | rejilla completa 72x72x48: 248 832 celdas, ultimo indice 248 831, `data` en [0,1], `layer` en 0..3 | test de escala |

Tolerancias: enteros, flags, capas y suelos exactos; alturas `1e-9` km; `normLogNe` `1e-12`; Ne contra referencia `1e-9` relativo. No se compara contra la propia implementacion: los valores esperados son pines del oraculo o una referencia `max()` independiente.

### 4.2 Prueba negativa

- Perfiles de tamano incorrecto: volumen `valid=false`, sin crash y con arrays del tamano esperado.
- `ne=0`, `ne<0`, NaN y `-Inf`: normalizacion 0; `+Inf`: 1; sin NaN propagado.
- `foE/foF1/foF2/hmF2` ausentes: flags falsos; no se inventa una capa.
- `f2FloorKm` sin E: `-1`; no se fuerza un suelo artificial.

### 4.3 Mutantes locales

Se ejecutan en local y se reportan; no se commitean:

| Mutante | Debe romper |
|---|---|
| `VOL_ALT_MAX_KM 500 -> 400` | G7.1/G7.3 |
| exponente `1.5 -> 1.0` | G7.3 |
| `volumeIndex` con `w/h` intercambiados | G7.2 (rejilla 3x2, no cuadrada) |
| rango log `4.5 -> 5.0` | G7.4 |
| `theta = radians(lon)` en `densityDir` | G7.5 |
| quitar puerta `f2Floor` | G7.8/G7.9 |
| `sanitizeB0` default `100 -> 90` | G7.7 |

Cada mutante debe tumbar al menos un test. Si no, el guard no esta cubierto.

---

## 5. Evidencia y verificacion

- `./gradlew --no-daemon testDebugUnitTest`: 0 fallos; los 254 tests actuales siguen verdes.
- `./gradlew --no-daemon assembleDebug`: PASS.
- `./gradlew --no-daemon lintDebug`: PASS.
- CI 3/3 (`assembleDebug`, `unitTest`, `lint`).
- `git diff --check`: PASS.
- Diff limitado a:
  - `app/src/main/java/com/valledemena/ionosphere/core/iono/DensityVolume.kt`
  - `app/src/main/java/com/valledemena/ionosphere/core/iono/LayerProfile.kt`
  - `app/src/test/java/com/valledemena/ionosphere/core/iono/DensityVolumeTest.kt`
  - `app/src/test/java/com/valledemena/ionosphere/core/iono/LayerProfileTest.kt`
- Sin `data/**`, `.github/**`, checker, UI o GL.
- No hay gate de dispositivo en R4.4: el plan le asigna JUnit; el primer gate visual es R4.5. No se pedira captura ni FPS.

Referencia de oraculo (hashes del pin, no del working tree):

| Fichero web en `8cdc334` | sha256 |
|---|---|
| `src/lib/iono/densityVolume.ts` | `e6abcc93b1fffc2f355d4f2e8b6c27f731dd1aecfb106971b4db19a45a24824d` |
| `src/lib/iono/densityVolume.test.ts` | `6b8dfc8f17c91f6c09a1f9ae60c5d7d65ba9084663ae5e38b899c7dbc7a2689b` |
| `src/lib/iono/layerProfile.ts` | `b4065ac86f1925a661d3411959b90e0ead20ab71dc323aea8a37fc73ede2d0e3` |
| `src/lib/iono/layerProfile.test.ts` | `dca30f5c771f45ceb12090c5f2ccae769f66588ccaaac28514139a59d2b0f1da` |

El working tree web tiene cambios ajenos en `next-env.d.ts` e `IonosphereScene.tsx`; la implementacion y los tests usan `git show 8cdc334:<fichero>`, no la copia sucia. El C++ `src/Ionosphere/DensityVolume.h` y `LayerProfile.h` queda como oraculo secundario, no como fuente de formulas nuevas.

---

## 6. Riesgos y mitigaciones

| Riesgo | Mitigacion |
|---|---|
| Repetir el bug de meridianos 180 grados | `densityDir` con pines exactos y `theta=pi-lon` |
| `B0` default 90 legacy vs 100 del oraculo | Usar 100, documentar la divergencia y test de saneado |
| Aproximar `f2FloorKm` y perder los 110/-1/167 | Barrido entero 1 km, pines exactos |
| Float vs Double cambia capas o suelos | Modelo puro en Double; conversion a Float solo en el boundary GL de R4.5 |
| Rejilla completa cara en JVM | Arrays planos `DoubleArray`/`IntArray`, sin objetos por celda; test de escala una vez |
| Scope creep a cortina/raymarch | Frontera de seccion 2.2; cualquier funcion extra va a su slice |
| Perfil inventado cuando falta dato | `blankProfile` y flags; `valid=false` si falta la rejilla; no rellenar estaciones |
| Copiar el oraculo en el test | Pines externos + referencia `max()` independiente |

---

## 7. Plan de ejecucion

1. Rama nueva desde `main` `84d4e9e`: `feat/r4.4-neh-volume-pure`.
2. Commit 1: constantes, `DensityVolume`, `volumeIndex`, `volumeAltKm`, `densityDir`, `normLogNe` + tests G7.1-G7.5.
3. Commit 2: `LayerProfile`, `applyDayNight`, `buildDensityVolume` + tests G7.6-G7.12.
4. Ejecutar tests, mutantes, `assembleDebug`, `lint`, `diff --check`.
5. Abrir PR con cuerpo que declare: oraculo, hashes, tests antes/despues, mutantes, fuera de alcance y ausencia de gate de dispositivo.
6. Revision hunk-a-hunk de GLM; GO de David; merge solo con GO.

No se empieza hasta que David confirme el alcance y GLM acepte la frontera de seccion 2.2.

---

## 8. Decisiones de frontera que pido confirmar (D1-D3)

1. **D1 - `applyDayNight` y `densityDir` en R4.4**: recomendado si, porque el builder no atenua E/F1 y sin ello el volumen nocturno no es paridad. `densityDir` entra como dependencia directa de `cosChi`. La version propuesta es funcional (devuelve lista nueva); confirmar que GLM no exige la mutacion de la web.
2. **D2 - Diferir los consumidores y el wiring**: recomendado; `extractPeakGrids`, `integrateTEC` y `sampleVolume` no hacen falta para G7 y pertenecen a R4.5/R4.6/R4.8. La tabla completa esta en la seccion 2.2.
3. **D3 - Modelo puro en `Double`**: recomendado; el boundary GL convierte a `Float` en R4.5.

Si David o GLM prefieren el paquete `core` plano en vez de `core/iono`, es un cambio mecanico sin efecto en el contrato.

Buffy - 2026-11-16
