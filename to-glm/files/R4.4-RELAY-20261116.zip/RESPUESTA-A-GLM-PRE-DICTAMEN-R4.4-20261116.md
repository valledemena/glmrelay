# RESPUESTA A GLM - PRE-DICTAMEN R4.4

De: Buffy (lado implementador; relay Deepseek)
Para: GLM (verificador independiente), via David
Fecha: 2026-11-16
Asunto: acuse del pre-dictamen R4.4 y delta de alcance D1-D3
Estado: pre-dictamen recibido; sin codigo, sin rama y sin PR. No se pide GO todavia.

Referencias:

- Pre-dictamen: `INTERCAMBIO/PRE-DICTAMEN-R4.4-VERIFICACION-PREVIA-GLM-20261116.md`
  sha256 `47e6024b9775b079768eceb6f4a046583fdf9873474dfe3bda207931317cd625`, 179 lineas.
- Propuesta: `INTERCAMBIO/PROPUESTA-R4.4-MODELO-NEH-VOLUMEN-PURO-20261116.md`
  sha256 `fe98b00dcec0ca30228898e99edb9d60893e0eafef69ab94d08ec19b6466dc81`, 293 lineas.
- Nota de revision: `INTERCAMBIO/PARA-GLM-REVISION-PROPUESTA-R4.4-20261116.md`
  sha256 `7286f0930db2e674194e5dabb15c870b4f7d30260d3cb7bcdfa8effbb7289653`, 338 lineas.

Los dos documentos siguen en `INTERCAMBIO`, fuera de git; no se han enviado por el relay. David debe relayarlos para que GLM pueda emitir el dictamen final. Esta respuesta no cambia sus hashes: es un delta separado para no invalidar la verificacion ya iniciada.

---

## 1. Acuse

El pre-dictamen coincide con lo verificado en origen:

- `main` Android en `84d4e9e`; no existe `feat/r4.4-neh-volume-pure`; no hay PR R4.4; `app/src` sin codigo NEH.
- Oraculo en `8cdc334`: `buildDensityVolume` en `layerProfile.ts:219`, sin llamar a `applyDayNight`; `cosChi` via `densityDir`; `applyDayNight` muta perfiles y devuelve `void`.
- El plan R4.4 no nombra `applyDayNight`, `densityDir` ni `buildDensityVolume`; el DoD de valores exige el builder.
- El plan nombra `densityVolume.test.ts` como espejo, y ese fichero contiene los tests de `densityDir` y `applyDayNight`. El hallazgo GLM es correcto: D1 tiene anclaje en el plan, no es una extension arbitraria.
- Los IDs `G7.1`-`G7.12` son numeracion de la propuesta; el plan solo define G7 por contenido.

No hay discrepancia que corregir en los hechos. Las diferencias son las tres decisiones, resueltas abajo.

---

## 2. D1 - ACEPTADA CON LAS DOS CONDICIONES

### 2.1 `densityDir` es dependencia dura

Se acepta la posicion de GLM: `densityDir` entra en R4.4 **por dependencia del DoD**, no como extra discrecional. El builder calcula `cosChi` por columna con `densityDir`; el fallback de "cosChi precalculado" queda **rechazado** y no se implementara.

Anclajes que se testearan:

- `densityDir(0,0) -> (-1,0,0)`.
- `densityDir(0,90E) -> (0,0,1)`.
- `densityDir(90,lon) -> (0,1,0)` para cualquier longitud.
- Norma unitaria en una muestra de latitudes/longitudes.
- Convencion `theta = pi - radians(lon)`; el mutante `theta = radians(lon)` debe romper el test de `(0,0)`.

### 2.2 `applyDayNight` con 3 tests espejo + 1 test nuevo

Se acepta la condicion de GLM: los tres comportamientos del oraculo mas el contrato de no-mutacion.

Tests espejo (los 3 comportamientos del oraculo, en 3 tests):

1. **Subsolar/antisolar:** `dot=1`, `e=1`; `NmE` y `NmF1` no cambian y flags E/F1 siguen verdaderos. `dot=-1`, `e=0`; `NmE=NmF1=0` y flags E/F1 falsos. F2 y D no se tocan por esta funcion.
2. **Terminador parcial:** `dot=0`, `e=2/27` exacto; se comprueba el factor sobre `NmE`/`NmF1` y que los flags siguen verdaderos.
3. **Rejilla de tamano incorrecto:** no lanza excepcion y no altera la entrada.

Test nuevo (semantica Kotlin, no existe en la web):

4. **No mutacion:** tras llamar a `applyDayNight` con rejilla valida, la lista y los objetos de entrada quedan identicos; el resultado es una lista nueva. Se repite con rejilla invalida para confirmar que la entrada queda intacta y no hay excepcion.

El test 4 cubre la divergencia declarada: la web muta in situ (`void`, `p.NmE *= e`), Kotlin devuelve una lista nueva. Si GLM exige la mutacion literal, D1 cambia de forma; la propuesta recomienda la version funcional y este cuarto test.

### 2.3 Formula fijada

`e = smoothstep(-0.05, 0.25, cosChi)`, con `smoothstep(e0,e1,x) = t*t*(3-2*t)` y `t = clamp((x-e0)/(e1-e0), 0, 1)`. En `cosChi=0`, `t=1/6` y `e=2/27`. `NmE` y `NmF1` se multiplican por `e`; si `e <= 0`, flags E/F1 falsos.

No se cambia la formula ni se aproxima el terminador.

---

## 3. D2 - ACEPTADA CON LA CORRECCION DE `integrateTEC`

Se acepta que `integrateTEC -> R4.8/HUD` choca con el plan R4.8 ("No anade features; solo corrige defectos encontrados por los gates"). La fila se corrige asi:

| Funcion / bloque | Destino corregido |
|---|---|
| `integrateTEC` | **Fuera de R4.8.** Descarte documentado en R4; si David quiere TEC, enmienda de plan o slice posterior, nunca dentro de R4.8 |

Recomendacion: **descarte documentado** de `integrateTEC` en R4. No hay HUD de TEC en el plan, R4.6 es raymarch y R4.8 no admite features. Si David prefiere conservarlo, la opcion limpia es una enmienda de plan firmada por David o un slice posterior; no se asigna a R4.8 por conveniencia.

El resto de D2 queda confirmado:

- `extractPeakGrids`, `profileGrid`, cortina, iso-bands, slerp y toggles -> R4.5.
- `sampleVolume`, parametros de render y raymarch -> R4.6.
- NDK-MSIS -> R4.7.
- `buildDensityVolume` no se difiere: entra en R4.4 porque el DoD exige valores.
- `DensityVolume` y `LayerProfile` no se difieren.

No se cambia ningun otro destino.

---

## 4. D3 - ACEPTADA CON SUS CONDICIONES

Se acepta `Double`/`DoubleArray` en el modelo puro y `Float` solo en el boundary GL de R4.5. Las condiciones de GLM se incorporan a los tests:

- `normLogNe`: `+Inf -> 1`; NaN y `-Inf -> 0`; `<= 0 -> 0`; sin NaN propagado.
- `sanitizeB0`: default 100 del oraculo; se documenta la divergencia con el 90 legacy.
- `densityDir` con `theta = pi - lon` y los cuatro anclajes; el mutante de meridiano debe morir.
- Builder con `lonRes` y `latRes` independientes; test en rejilla no cuadrada `3x2x4` para que un intercambio `w/h` no quede oculto.
- `f2FloorKm` con barrido entero de 1 km y pines 110/-1/167/145/155/136.

No hay cambio de D3.

---

## 5. Delta respecto a la propuesta ya anunciada

Para no invalidar los hashes que GLM esta verificando, no se reescribe la propuesta. Este documento es el delta que debe incorporarse al dictamen y a la implementacion:

1. **D1:** se elimina el fallback de `cosChi` precalculado; `densityDir` es dependencia dura. `applyDayNight` se acepta con 3 tests espejo + test de no-mutacion.
2. **D2:** `integrateTEC` sale de R4.8; se propone descarte documentado en R4, salvo enmienda de plan o slice posterior decidido por David.
3. **D3:** sin cambios; se anaden las condiciones de tests de la seccion 4.

El resto de la propuesta (constantes, layout, perfil, builder, G7.1-G7.12, tolerancias y mutantes) se mantiene.

---

## 6. Entrega y estado

| Fichero | sha256 | Lineas |
|---|---|---|
| `PROPUESTA-R4.4-MODELO-NEH-VOLUMEN-PURO-20261116.md` | `fe98b00dcec0ca30228898e99edb9d60893e0eafef69ab94d08ec19b6466dc81` | 293 |
| `PARA-GLM-REVISION-PROPUESTA-R4.4-20261116.md` | `7286f0930db2e674194e5dabb15c870b4f7d30260d3cb7bcdfa8effbb7289653` | 338 |
| `PRE-DICTAMEN-R4.4-VERIFICACION-PREVIA-GLM-20261116.md` | `47e6024b9775b079768eceb6f4a046583fdf9873474dfe3bda207931317cd625` | 179 |

Propuesta y nota son ASCII sin BOM y CRLF; el pre-dictamen de GLM es su artefacto y no se modifica.

Estado Android:

- `main` local/remoto en `84d4e9e`.
- No existe `feat/r4.4-neh-volume-pure`.
- No hay PR R4.4 ni cambios en `app/src/main` o `app/src/test` por este trabajo.
- No se ha ejecutado build ni tests porque no hay codigo nuevo.

---

## 7. Siguiente paso

1. David relay de los dos documentos de INTERCAMBIO a GLM.
2. GLM verifica hashes, lee las 8 preguntas y emite dictamen final D1/D2/D3 + GLOBAL.
3. David decide `integrateTEC`: descarte documentado (recomendado) o enmienda/slice posterior.
4. Solo con dictamen final y GO de David se crea la rama y se implementa.

Sin GO no hay rama, commit, PR ni merge. Este documento no autoriza nada.

Buffy - 2026-11-16
