PACKAGE R4.4 - SCOPE REVIEW FOR GLM
==================================

Date: 2026-11-16
Origin: Buffy / Deepseek (INTERCAMBIO Windows)
Destination: GLM canonical INTERCAMBIO, via David

Purpose: relay the R4.4 scope proposal, the GLM review note and the
response to GLM's pre-dictamen. This is a scope-review package only.
No Android code, branch, PR or merge is part of it.

Contents
--------
1. PROPUESTA-R4.4-MODELO-NEH-VOLUMEN-PURO-20261116.md
   sha256 fe98b00dcec0ca30228898e99edb9d60893e0eafef69ab94d08ec19b6466dc81
   293 lines, ASCII without BOM, CRLF.
2. PARA-GLM-REVISION-PROPUESTA-R4.4-20261116.md
   sha256 7286f0930db2e674194e5dabb15c870b4f7d30260d3cb7bcdfa8effbb7289653
   338 lines, ASCII without BOM, CRLF.
3. RESPUESTA-A-GLM-PRE-DICTAMEN-R4.4-20261116.md
   sha256 2af5df2f6eefdbefed3896840b95c6d841078e8c3b30a78c1ce63c7d56266fd9
   150 lines, ASCII without BOM, CRLF.
4. README-RELAY-R4.4.txt (this file)
5. SHA256SUMS (native, LF; verify with: sha256sum -c SHA256SUMS)

Not included on purpose:
- PRE-DICTAMEN-R4.4-VERIFICACION-PREVIA-GLM-20261116.md is GLM's own
  artifact, already on the GLM side; it is not re-deposited here.
- No Android source, no app/src, no data/**, no .github/**, no checker.
- No pre-dictamen, no code diff, no build artifact.

Reading order
-------------
1. PROPUESTA (scope and contract).
2. PARA-GLM (three decisions D1-D3, deferred functions, questions).
3. RESPUESTA (delta accepting GLM's pre-dictamen conditions).

Open decision
-------------
D2: integrateTEC is out of R4.8. The response recommends documented
discard from R4; David may instead amend the plan or open a later
slice. It is not assigned to R4.8.

Protocol
--------
  unzip R4.4-RELAY-20261116.zip -d destino
  cd destino
  sha256sum -c SHA256SUMS

State: main Android = 84d4e9e; no feat/r4.4-neh-volume-pure; no PR;
no changes in app/src/main or app/src/test. No GO from David yet.

Buffy - 2026-11-16
