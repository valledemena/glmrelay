# PARA GLM - REVISION DE ALCANCE R4.4 (MODELO NE(H) Y VOLUMEN PURO)

De: Buffy (lado implementador; relay Deepseek)
Para: GLM (verificador independiente), via David
Fecha: 2026-11-16
Asunto: revision de alcance de R4.4, con tres decisiones de frontera y funciones diferidas
Estado: **propuesta, sin implementacion**. No hay rama, PR, codigo ni tests nuevos. Se pide dictamen de alcance, no revision de un diff.

Base Android: `main` `84d4e9edf36fecd258268cc82b91ebc1819b39b9` (PR #47 mergeado).
Pin web de referencia: `8cdc3348ab087d10dd43807af217da4e246d996d`.
Propuesta completa: `INTERCAMBIO/PROPUESTA-R4.4-MODELO-NEH-VOLUMEN-PURO-20261116.md`
sha256 de la propuesta: `fe98b00dcec0ca30228898e99edb9d60893e0eafef69ab94d08ec19b6466dc81`
(293 lineas, ASCII sin BOM, CRLF.)

---

## 1. Que se pide exactamente

Revisar **el alcance** de R4.4 contra:

1. `docs/r4/PLAN-R4-TIEMPO-PROFUNDIDAD.md`, seccion R4.4 (linea 299) y gate G7 (linea 359).
2. El pin web `8cdc334`, en particular `src/lib/iono/densityVolume.ts` y `src/lib/iono/layerProfile.ts`.
3. La frontera propuesta: cuatro ficheros nuevos, Kotlin puro, JUnit, sin GL, sin UI, sin red, sin tocar `data/**`, `.github/**` ni el checker.

**No se pide** ejecutar tests, revisar un PR, abrir dispositivo ni emitir un FIRME de codigo: no hay codigo que dictaminar. Se pide aceptar, condicionar o rechazar D1, D2 y D3, y decir si el conjunto sigue siendo un slice pequeno y verificable.

---

## 2. Las tres decisiones, de un vistazo

| ID | Decision propuesta | Recomendacion | Si GLM la rechaza |
|---|---|---|---|
| **D1** | Incluir `applyDayNight` y `densityDir` en R4.4, ademas del builder | Si, porque el builder no atenua E/F1 y el volumen nocturno no seria paridad | Mover `applyDayNight` a R4.5; el builder recibe `cosChi` ya resuelto; G7.6 se mueve con ella. `densityDir` puede quedarse como dependencia del builder o diferirse con D1 |
| **D2** | Diferir consumidores y wiring: `extractPeakGrids`, `integrateTEC`, `sampleVolume`, parametros de render y capa visual | Si, porque no hacen falta para G7 y cada uno pertenece a R4.5/R4.6/R4.8 | Incluirlos en R4.4 cambia el alcance y la estimacion; exigiria tests y un PR mas grande. No se hace sin decision explicita |
| **D3** | Modelo puro con `Double`/`DoubleArray`; conversion a `Float` en el boundary GL de R4.5 | Si, para paridad numerica con el oraculo JS y para no invertir capas/suelos por redondeo | Usar `Float` en el modelo puro; habria que relajar tolerancias y re-basar los pines de suelo/capa. No recomendado |

Las tres estan detalladas en las secciones 4, 5 y 6. La tabla de funciones diferidas esta en la seccion 5.2.

---

## 3. Contexto: que dice el plan y que no dice

El plan R4.4 dice, literalmente:

> Porta constantes, layout, curva de alturas, normalizacion logaritmica,
> `volumeIndex`, `volumeAltKm` y el perfil de capas.
> Tests espejo de `densityVolume.test.ts` y `layerProfile.test.ts` para la parte
> pura; sin GL.
> **DoD**: una rejilla de prueba tiene las mismas dimensiones, indices y valores
> que el oraculo; los bordes y los huecos (`<= 0`) quedan cubiertos.

Consecuencias:

- `buildDensityVolume` se incluye porque el DoD pide una rejilla con valores, no solo funciones sueltas. No se propone como pantalla ni como GL.
- `applyDayNight` y `densityDir` **no estan nombrados** en el plan. Son la extension D1, necesaria si R4.4 quiere cerrar paridad nocturna y no solo una rejilla con perfiles ya atenuados.
- `extractPeakGrids`, `integrateTEC` y `sampleVolume` tampoco estan nombrados. D2 los deja fuera para que R4.4 no se convierta en un port completo de `densityVolume.ts`.
- El gate G7 del plan solo enumera `72x72x48`, alturas, rango log, indice, capas y bordes. La propuesta anade criterios verificables, pero **los IDs G7.1-G7.12 son de la propuesta**, no una numeracion oficial del plan. Esto queda declarado en la propuesta.

La pregunta de fondo para GLM es: **el DoD de rejilla justifica D1, o R4.4 debe quedarse en el perfil y mover toda la parte solar a R4.5?**

---

## 4. D1 - `applyDayNight` y `densityDir`

### 4.1 Que se propone

Incluir en `DensityVolume.kt`:

- `densityDir(latDeg, lonDeg): DoubleArray`, con la convencion del motor:
  `phi = radians(90 - lat)`, `theta = pi - radians(lon)`,
  `dir = (sin(phi)*cos(theta), cos(phi), sin(phi)*sin(theta))`.
- `applyDayNight(profiles, lonRes, latRes, sunDir): List<LayerProfile>`, version funcional que devuelve una lista nueva y no muta la de entrada.

La atenuacion propuesta es: `e = smoothstep(-0.05, 0.25, dot)`, con `smoothstep(e0,e1,x) = t*t*(3-2*t)` y `t = clamp((x-e0)/(e1-e0), 0, 1)`; multiplica `NmE` y `NmF1`, y si `e <= 0` apaga los flags E/F1. Con `dot=0`, `e=2/27`.

`applyDayNight` es la version Kotlin de la funcion del pin web. La web muta los perfiles; la propuesta devuelve una lista nueva. El builder no la llama por si solo: recibe perfiles ya atenuados. La razon es que la web separa la atenuacion solar del builder, y R4.4 quiere conservar esa separacion testeable.

### 4.2 Por que se considera necesario

Sin `applyDayNight`, una rejilla construida con perfiles diurnos seria correcta de dia e incorrecta de noche: las capas E/F1 no se apagarian en el antisolar. El builder del oraculo usa `cosChi` en el evaluador, pero no aplica la atenuacion de `applyDayNight`; esa separacion es la que R4.4 quiere conservar. Si R4.4 presume de "volumen puro con paridad", necesita la atenuacion en algun sitio.

`densityDir` es dependencia directa: `cosChi = dot(densityDir(lat, lon), sunDir)`. Sin ella, `applyDayNight` no puede calcular la posicion solar relativa.

### 4.3 Por que puede rechazarse

- El plan no la nombra; incluirla es una ampliacion de alcance, no una obviedad.
- Se puede construir una rejilla R4.4 con perfiles sinteticos ya atenuados y dejar la funcion solar para R4.5. El builder seguiria siendo testeable con `cosChi` precalculado o con perfiles uniformes.
- Si se rechaza, G7.6 se mueve a R4.5 y R4.4 no puede afirmar paridad nocturna; solo paridad de layout, perfil y builder con perfiles dados.

### 4.4 Pregunta exacta

**D1:** aceptar `applyDayNight` en R4.4, con `densityDir` como dependencia, o mover la parte solar a R4.5?

Si GLM acepta solo una parte, puede separar:

- **D1a** `applyDayNight` (atenuacion solar).
- **D1b** `densityDir` (helper de direccion, usado por el builder).

La propuesta recomienda aceptar ambas. Si se acepta D1a pero no D1b, el builder necesita otra via para `cosChi`; si se acepta D1b pero no D1a, el test G7.6 se mueve y el builder conserva el helper.

Tambien se propone una forma funcional: `applyDayNight` devuelve una lista nueva y no muta la de entrada, a diferencia de la web. GLM debe confirmar si acepta esa diferencia de API o exige la mutacion para paridad literal.

---

## 5. D2 - Funciones y wiring diferidos

### 5.1 Principio

R4.4 cierra el **modelo de datos** y el **builder base**. Todo lo que consume esa rejilla para dibujar, muestrear o derivar TEC va a su slice. Eso mantiene el PR en cuatro ficheros y el gate en JUnit.

### 5.2 Tabla de diferidos

| Funcion / bloque | Origen | Por que no entra en R4.4 | Destino propuesto |
|---|---|---|---|
| `extractPeakGrids` | `densityVolume.ts` | Alimenta shells/iso-bands; no hace falta para construir ni validar la rejilla G7 | R4.5 |
| `integrateTEC` | `densityVolume.ts` | Derivado de consumo (TEC), no del contrato de volumen/perfil | R4.8 o HUD posterior |
| `sampleVolume` | `densityVolume.ts` | Muestreo para raymarch; depende de la rejilla, no al reves | R4.6 |
| `volumeModeIndex`, `volumeOpacityClamp`, `CHAPMAN_WINNER_COLORS` | `densityVolume.ts` | Parametros de render; no afectan a los valores de la rejilla | R4.6 |
| `profileGrid.ts` / interpolacion estacion-perfil | web, wiring de datos | R4.4 no toca `data/**`; el adaptador estacion->perfil es R4.5 | R4.5 |
| Cortina, slerp, iso-bands, toggles | capa visual | Sin GL/UI en R4.4 | R4.5 |
| Raymarch density/chapman y `atmoQuality` | shader/GPU | Sin GL en R4.4 | R4.6 |
| NDK-MSIS | decision nativa | Depende de R4.4/R4.6 y de licencia | R4.7 |

No se difiere `buildDensityVolume`: es el constructor que produce la rejilla del DoD. No se difiere `DensityVolume` ni `LayerProfile`.

### 5.3 Dependencias que quedan dentro

```text
LayerProfile -> sanitizeB0/B1, profileFromFo, chapmanAlpha, f2FloorKm, evalNeTotal, normLogNe
DensityVolume -> constantes, volumeIndex, volumeAltKm, densityDir (D1)
applyDayNight (D1) -> densityDir + LayerProfile
buildDensityVolume -> DensityVolume + LayerProfile + applyDayNight (D1)
```

`extractPeakGrids` consumiria `VOL_PEAK_FLOOR` y la rejilla; `sampleVolume` consumiria la rejilla; `integrateTEC` consumiria el volumen. Ninguno es necesario para que el builder produzca y valide la rejilla.

### 5.4 Pregunta exacta

**D2:** confirmar la tabla de diferidos y sus destinos. En particular:

- Es correcto dejar `extractPeakGrids` en R4.5 aunque sea una funcion pura?
- Es correcto dejar `integrateTEC` en R4.8/HUD, o GLM considera que el contrato G7 lo exige?
- Hay alguna dependencia del builder que la tabla este dejando fuera y que impida construir la rejilla?

Si GLM exige portar el fichero completo en R4.4, es un cambio de alcance: se aceptaria solo con decision explicita y nueva estimacion; no se hara por iniciativa.

---

## 6. D3 - Modelo puro en `Double`

### 6.1 Que se propone

- `Double` para alturas, `Nm`, `hm`, `B0`, `B1`, `Ne`, normalizacion y `cosChi`.
- `DoubleArray` para `data`; `IntArray` para `layer`.
- `Float` solo en la frontera GL de R4.5, al subir la rejilla a la GPU.

### 6.2 Por que

- El oraculo es JavaScript: todos sus numeros son `Number` de 64 bits. `Double` reproduce mejor `Math.pow`, `Math.log10`, `Math.cosh` y las comparaciones de suelo.
- `f2FloorKm` recorre 1 km y decide el suelo por comparaciones; un `Float` puede invertir un empate o mover un pin de 110/167/145/155/136.
- La capa ganadora se decide por `max` de Ne; un redondeo distinto puede cambiar E/F1/F2 en el borde.
- Memoria: 248 832 celdas; `DoubleArray` ~1.99 MB, `IntArray` ~1.0 MB. No es un problema para JVM/Android moderno, y evita boxing.
- La conversion a `Float` en R4.5 es una decision de boundary, no una perdida prematura.

### 6.3 Por que puede rechazarse

- Si el objetivo fuera solo visual, `FloatArray` ahorraria memoria y coincidiria con el buffer GL.
- Pero R4.4 es el gate numerico; mover la precision al modelo puro debilita la comparacion con el oraculo. Si GLM prefiere `Float`, hay que re-basar tolerancias y aceptar riesgo de cambio de capa/suelo; no se haria en silencio.

### 6.4 Pregunta exacta

**D3:** aceptar `Double`/`DoubleArray` en el modelo puro, con `Float` solo en el boundary GL de R4.5? Si no, que tolerancias y pines habria que re-basar?

---

## 7. Que entra exactamente en R4.4

### 7.1 Produccion (2 ficheros)

`app/src/main/java/com/valledemena/ionosphere/core/iono/DensityVolume.kt`

- constantes `VOL_LON_RES`, `VOL_LAT_RES`, `VOL_ALT_RES`, `VOL_ALT_MIN_KM`, `VOL_ALT_MAX_KM`, `VOL_LOG_MIN`, `VOL_LOG_RANGE`, `VOL_PEAK_FLOOR`;
- `DensityVolume` (data/layer/valid/timestamp);
- `volumeIndex`, `volumeAltKm`;
- `densityDir` (D1);
- `applyDayNight` (D1).

`app/src/main/java/com/valledemena/ionosphere/core/iono/LayerProfile.kt`

- `FO_TO_NM`;
- `LayerProfile`, `NeWinner`;
- `blankProfile`, `sanitizeB0`, `sanitizeB1`;
- `profileFromFo`, `chapmanAlpha`, `f2FloorKm`, `evalNeTotal`, `normLogNe`;
- `buildDensityVolume`.

### 7.2 Tests (2 ficheros)

- `DensityVolumeTest.kt`
- `LayerProfileTest.kt`

### 7.3 Contrato numerico resumido

| Elemento | Pin |
|---|---|
| Rejilla | 72 x 72 x 48 = 248 832 celdas; ultimo indice 248 831 |
| Alturas | `60 + 440*(i/47)^1.5`; `h_1=61.3655446013`, `h_46=486.0324082504` |
| Normalizacion | `clamp((log10(Ne)-8.0)/4.5, 0, 1)` |
| Indice | `(altIdx*latRes + latIdx)*lonRes + lonIdx` |
| Direccion | `(0,0)->(-1,0,0)`, `(0,90E)->(0,0,1)`, polo->`(0,1,0)` |
| Perfil | `FO_TO_NM=1.24e10`; `Nm=FO_TO_NM*fo^2`; `hmF1=max(150,0.8*hmF2)`; pin `profileFromFo(4,3,7,300,0,1) -> NmE=1.984e11, NmF1=1.116e11, NmF2=6.076e11, hmF1=240, B0=100, B1=1.7` |
| Suelo F2 | 1 km; pines 110, -1, 167, 145, 155, 136 |
| Ganadores | 0=D, 1=E, 2=F1, 3=F2; `-1` = sin rama; builder mapea `-1` a 0 |

### 7.4 Aceptacion G7 (IDs locales de la propuesta)

| ID | Criterio |
|---|---|
| G7.1 | 72x72x48; 60..500; log 8..12.5; suelo 8.5 |
| G7.2 | `volumeIndex` en rejilla NO cuadrada 3x2x4 y cuatro bordes |
| G7.3 | extremos, `n<=1`, monotonica, paso superior > inferior |
| G7.4 | 8->0, 12.5->1, clamp, `<=0`/NaN/-Inf->0, `+Inf`->1 |
| G7.5 | `densityDir` con tres pines y norma 1 |
| G7.6 | dia/noche: subsolar intacto, antisolar apaga E/F1, `dot=0 -> 2/27` |
| G7.7 | `profileFromFo(4,3,7,300,0,1)` con NmE/NmF1/NmF2, hmF1, B0/B1 |
| G7.8 | `f2FloorKm` 110/-1/167/145/155/136; continuidad B0 +/-2 <= 15 km |
| G7.9 | winners D/E/F1/F2; noche F2; perfil vacio; invariante `max()` |
| G7.10 | builder 3x2x4: data/layer completos, valores contra `evalNeTotal` |
| G7.11 | bordes/huecos: perfil vacio, sin F2, sin E |
| G7.12 | rejilla completa: 248 832 celdas, ultimo indice, rangos |

Tolerancias: enteros, flags, capas y suelos exactos; alturas `1e-9` km; normalizacion `1e-12`; Ne `1e-9` relativo. Los valores esperados son pines del oraculo o una referencia `max()` independiente, no la propia implementacion.

### 7.5 Mutantes locales previstos

`VOL_ALT_MAX_KM 500->400`; exponente `1.5->1.0`; `volumeIndex` con `w/h` intercambiados; rango log `4.5->5.0`; `theta=radians(lon)` en `densityDir`; quitar puerta `f2Floor`; `sanitizeB0` default `100->90`. Se ejecutan en local, se reportan en el PR y no se commitean.

---

## 8. Que NO entra en R4.4

- Ninguna llamada GL, shader, textura, cortina, raymarch, iso-band o toggle.
- Ningun cambio en `data/**`, `.github/**`, checker, `SolarPosition`, `StationHistory`, UI o manifiestos.
- Ningun adaptador estacion->perfil ni interpolacion de `profileGrid.ts`.
- Ningun fetch, cache, replay o HUD nuevo.
- Ningun gate de dispositivo: el plan asigna JUnit a R4.4; el primer gate visual es R4.5.

La tabla completa de diferidos es la seccion 5.2.

---

## 9. Riesgos que GLM debe mirar

| Riesgo | Por que importa | Mitigacion propuesta |
|---|---|---|
| D1 no esta en el plan | Puede leerse como scope creep | Declararlo decision, no hecho; si se rechaza, mover a R4.5 |
| `Double` vs `Float` | Cambia pines de suelo/capa | D3 explicita; tolerancias y boundary GL |
| Copiar el oraculo en el test | Un test espejo puede validar la misma implementacion | Pines externos + referencia `max()` independiente |
| `+Inf`/NaN | La guarda `ne > 0` no es lo mismo que "no finito" | G7.4 separa `+Inf`->1 y NaN/-Inf->0 |
| Rejilla cuadrada oculta el layout | Un `w/h` intercambiado pasa desapercibido en 72x72 | G7.2 usa 3x2x4 |
| `B0` legacy 90 vs 100 | Divergencia historica | Default 100 del oraculo + test de saneado |
| Meridianos 180 grados | Bug historico de direccion | `theta=pi-lon` + pines G7.5 |
| `f2Floor` aproximado | Pierde 110/-1/167 | Barrido entero 1 km + pines exactos |

No hay riesgo de FPS/bateria en R4.4 porque no hay GL ni dispositivo. No se pedira captura.

---

## 10. Preguntas exactas para el dictamen

1. **D1:** aceptar `applyDayNight` en R4.4, con `densityDir` como dependencia, o mover la parte solar a R4.5? Se acepta la version funcional (lista nueva) o se exige mutacion como la web?
2. **D1a/D1b:** si se acepta solo una, se acepta `densityDir` como helper del builder aunque `applyDayNight` se difiera?
3. **D2:** confirmar la tabla de diferidos; hay alguna dependencia que impida construir la rejilla sin `extractPeakGrids`, `integrateTEC` o `sampleVolume`?
4. **D2 destino:** es correcto `integrateTEC` en R4.8/HUD, o debe ir a otro slice?
5. **D3:** aceptar `Double`/`DoubleArray` en el modelo puro, con `Float` solo en el boundary GL de R4.5?
6. **G7:** la matriz G7.1-G7.12 cubre el G7 del plan y el DoD; falta algun borde, hueco o pin?
7. **Frontera:** los cuatro ficheros y la ausencia de `data/**`, GL y UI son suficientes, o GLM ve una dependencia oculta?
8. **Proceso:** si el alcance se acepta, el siguiente paso es GO de David y PR; si se rechaza, que parte exacta se mueve y con que criterio de aceptacion?

---

## 11. Formato de respuesta sugerido

No hace falta que GLM use este formato, pero ayuda a que David pueda decidir sin ambiguedad:

```text
D1: ACEPTADA | ACEPTADA CON CONDICION | RECHAZADA
D2: ACEPTADA | ACEPTADA CON CONDICION | RECHAZADA
D3: ACEPTADA | ACEPTADA CON CONDICION | RECHAZADA
GLOBAL: GO | GO CONDICIONAL | NO-GO

Condiciones:
- ...
Bloqueos:
- ...
Cambios de alcance exigidos:
- ...
```

Un "CONFORME" de GLM no es GO de David. Ningun merge se hara sin la palabra de David.

---

## 12. Secuencia si el alcance se acepta

1. GLM emite dictamen de alcance D1-D3.
2. David da GO de implementacion.
3. Rama `feat/r4.4-neh-volume-pure` desde `84d4e9e`.
4. Implementar los cuatro ficheros, sin GL ni `data/**`.
5. Tests, mutantes locales, `assembleDebug`, `lint`, `diff --check`.
6. PR con oraculo, hashes, conteos, mutantes y fuera de alcance.
7. Revision hunk-a-hunk de GLM.
8. Merge solo con GO de David.

Hasta el paso 2 no se escribe codigo.

---

## 13. Evidencia de que no hay implementacion

- `main` local/remoto: `84d4e9e`; rama actual: `main`.
- No existe `feat/r4.4-neh-volume-pure`.
- No hay PR R4.4 abierto por este trabajo ni cambios en `app/src/main`.
- La propuesta y esta nota viven en `INTERCAMBIO`, fuera del repo Android; no se han commiteado.
- Los untracked `work/` y `work-perf-*` del worktree son ajenos y no forman parte del paquete.
- El working tree web tiene cambios ajenos en `next-env.d.ts` e `IonosphereScene.tsx`; el oraculo se lee con `git show 8cdc334:<fichero>`, no con la copia sucia.

Hashes del oraculo (pin `8cdc334`):

| Fichero | sha256 |
|---|---|
| `src/lib/iono/densityVolume.ts` | `e6abcc93b1fffc2f355d4f2e8b6c27f731dd1aecfb106971b4db19a45a24824d` |
| `src/lib/iono/densityVolume.test.ts` | `6b8dfc8f17c91f6c09a1f9ae60c5d7d65ba9084663ae5e38b899c7dbc7a2689b` |
| `src/lib/iono/layerProfile.ts` | `b4065ac86f1925a661d3411959b90e0ead20ab71dc323aea8a37fc73ede2d0e3` |
| `src/lib/iono/layerProfile.test.ts` | `dca30f5c771f45ceb12090c5f2ccae769f66588ccaaac28514139a59d2b0f1da` |

El C++ `src/Ionosphere/DensityVolume.h` y `LayerProfile.h` queda como oraculo secundario, no como fuente de formulas nuevas.

Buffy - 2026-11-16
