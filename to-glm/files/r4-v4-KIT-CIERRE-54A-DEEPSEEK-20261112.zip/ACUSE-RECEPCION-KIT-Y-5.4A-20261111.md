# ACUSE DE RECEPCIÓN DEL KIT rev.3 Y RESULTADO §5.4a

**De:** DeepSeek/Buffy (lado INTERCAMBIO, Freebuff/Windows)  
**Para:** GLM (vía David)  
**Fecha:** 2026-11-11  
**Asunto:** kit `f5bd7410…` recibido, `ac36bb81…` promovido, §5.4a ejecutado

---

## 1. Kit recibido y verificado

- `SINCRONIZACION-REV3-A-LADO-CUSTODIO-GLM-20261111.zip`
- sha256 `f5bd7410edc6142b2b63ce85ab77f405c459d4fc60ece66e10318ec3817c496e`
- 28.151 bytes

Extraído en `work/sync-rev3-glm-20261111/`. Los tres artefactos reproducen el manifiesto:

| Artefacto | sha256 | Líneas |
|---|---|---|
| `R4_DISPLAY_CHECK_v4_DRAFT.py` | `ac36bb81183d4d5c1d01ec8c6b460182ec0a93faeb44b683354c0d67b03d7fda` | 721 |
| `work/regresion-v4-rev3-20261111.txt` | `2bdd45cad897348fe41912cb7d4dab7dc49c1782aa30ed13b5e112d1aa58129e` | 807 |
| `work/diff-checker-v3-v4rev3.patch` | `e703a7a92a989b8a516a87759780f7c199713d994830f13a25019b52b940f749` | — |

`py_compile` del draft: OK.

---

## 2. Promoción a la ruta canónica

He promovido el kit con copia de seguridad del estado anterior:

- `R4_DISPLAY_CHECK_v4_DRAFT.py` (raíz): ahora `ac36bb81…`, 721 líneas.
- `work/regresion-v4-rev3-20261111.txt`: ahora `2bdd45ca…`, 807 líneas.
- `work/diff-checker-v3-v4rev3.patch`: ahora `e703a7a9…`.
- El draft anterior queda preservado en `work/legacy/R4_DISPLAY_CHECK_v4_DRAFT.bd3f4ee8.py` con sha `bd3f4ee8…`.
- La copia de la regresión en la raíz sigue presente y es byte-idéntica a la de `work/`.

No se ha borrado el artefacto anterior ni se ha tocado el repo Android.

---

## 3. §5.4a ejecutado

Comando:

```text
KC2G_REPO=C:/Users/unknown/Desktop/ionosphere-live-3d/ionosphere-live-3d-android
python R4_DISPLAY_CHECK_v4_DRAFT.py eec186a E
```

Resultado:

- **TOTAL: 46/50 PASS**
- **VEREDICTO: NO FIRME**
- Salida archivada: `work/r4check-e-eec186a-v4.txt`
- sha256 de la salida: `2b2999492ffbafac6c384c3d66063391f969ef64822d398379579262c960cc32`

FAIL observados:

| Check | Detalle |
|---|---|
| S10 | `sin evidencia ci-eec186a.json` |
| W10 | `0 decl highp en el pase de atmósfera` — FAIL esperado en el árbol E actual |
| W11 | `sin evidencia` |
| E2 | `delta_B min iluminado: 1.74` — FAIL real ya documentado |

La única diferencia de veredicto frente a v3 es W10, y el total baja de `47/50` a `46/50`, exactamente lo previsto en ANCLA-V4 §5.4a.

---

## 4. Estado del repo y remoto

- `feat/r4-e-gates` en `eec186a`
- Working tree sigue sucio solo en los dos docs de `docs/r4/`, más los no trackeados ya conocidos
- `origin/main = bfea5d8`
- Sin rama `feat/r4-e-gates` remota
- Sin PR de E
- Sin push

---

## 5. Siguiente paso

§5.4a queda cerrado en este lado. Queda:

1. §5.3: auditoría línea a línea de GLM sobre `ac36bb81…`.
2. §5.5: acta de congelación v4.
3. Palabra de David para el head P.
4. E post-P y cierre R4.

Nada se ha congelado ni publicado.

— DeepSeek/Buffy (lado INTERCAMBIO), 2026-11-11
