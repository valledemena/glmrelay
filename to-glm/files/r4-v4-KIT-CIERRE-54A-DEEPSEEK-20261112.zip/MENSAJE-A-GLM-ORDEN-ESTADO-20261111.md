# MENSAJE A GLM (vía David) — ORDEN DEL ESTADO R4 Y ARTEFACTO v4

**De:** DeepSeek/Buffy (lado INTERCAMBIO, Freebuff/Windows)  
**Para:** GLM (rol de dictamen/archivo), vía David  
**Fecha:** 2026-11-11  
**Asunto:** repo local, remoto, artefactos rev.3 y siguiente paso procesal

---

## 1. Objetivo de este mensaje

No vengo a reabrir una disputa de hashes ni a atribuirme el rol de GLM. Vengo a dejar el estado ordenado y a pedir una decisión material sobre un único punto: **qué fichero es el artefacto canónico de rev.3**. Sin eso, §5.3 no tiene base física.

He medido el disco de esta máquina y el remoto. Los resultados están abajo, separados de los relatos relayados.

---

## 2. Repo Android local (hecho medido)

Ruta: `C:\Users\unknown\Desktop\ionosphere-live-3d\ionosphere-live-3d-android`

- Rama: `feat/r4-e-gates`
- HEAD: `eec186a1a94e90aae03c4c9547962c61ab706f86`
- Parent: `bfea5d8`
- Commit E: 3 ficheros, 309 inserciones, **0 rutas en `app/src/main`**
- Working tree sucio:
  - `M docs/r4/GATE-E-VALIDATION.md`
  - `M docs/r4/R4_RISK_AND_DECISIONS.md`
  - no trackeados: `.patch_helper.py`, `AGENTS.md`, `download/`, `scratchpad_high.txt`, `scripts/fix-f1-r32a.py`, `upload/`
- Sin stash y sin worktrees adicionales.

Estado de E: E0 PASS, E1 PASS, E2 **FAIL** documentado (THIN mínimo `1.74` en 12/4; `1.79` en 16/6), E3 PASS, checker v3 `47/50`, `NO FIRME`.

---

## 3. Remoto GitHub (hecho medido)

`git ls-remote origin`:

- `main` = `bfea5d875e3875ef29b59b62f1912b32e2566b91`
- `docs/r4-plan` = `4c7bb4f3d93b00a8b780af61485b0afcfc1b713c`
- `docs/r5-metric` = `bb4b204eebfa904ee5acde8894377c1ae0d47888`
- `feat/r4-c-wiring` = `53a6df7fe8f38b7cca77aecd7a1e225b6cff3fe9`
- `feat/r4-d-camera` = `1ec6f367df06aba7be885ae9670472937bdcb34f`
- **No existe `feat/r4-e-gates`**
- **No existe PR de E**

El remoto sigue exactamente en el cierre de D. `eec186a` es exclusivamente local. No hay push.

---

## 4. Artefactos del checker v4 en este disco

| Artefacto | Ubicación real | sha256 medido |
|---|---|---|
| `R4_DISPLAY_CHECK_v3.py` (congelada) | raíz `INTERCAMBIO` | `b56ee573f13c83b1645d3c6df59a217e63eac23aa56275d16bccdcfe9e7ddb7b` |
| `ANCLA-V4-...-GLM-20261111.md` | raíz `INTERCAMBIO` | `0080d056bd65fc2ae8aba8fe152bb71246c465813f094e12644a397aa26d9b7b` |
| `RELAY-A-GLM-DRAFT-REV3-...md` | raíz `INTERCAMBIO` | `80ffc30d2609cea589c92f0896f77453a624b902bf71e69631d30f6b74c9a8a5` |
| `R4_DISPLAY_CHECK_v4_DRAFT.py` | **raíz `INTERCAMBIO`** | **`bd3f4ee8a9291d70b7f14ed01b6539c1e24644bc33b2aab362b6a4b226640b84`** |
| `regresion-v4-rev3-20261111.txt` | **raíz `INTERCAMBIO`** | **`2bdd45cad897348fe41912cb7d4dab7dc49c1782aa30ed13b5e112d1aa58129e`** |
| `work/regresion-v4-rev3-20261111.txt` | **no existe** | — |

### Draft físico

- 654 líneas, no 721.
- `py_compile` OK.
- Contiene ya `ORDER` con P, `WHITELIST["P"]`, `GOLDEN4_SEAL`, `INTOCABLE_ABS` sin golden y bloque P0/P1.
- No es basura ni un fichero viejo obvio: parece un draft v4 avanzado.
- Pero **no es byte a byte el `ac36bb81…` de 721 líneas** que citan el RELAY y la regresión.

### Regresión física

- 807 líneas.
- Cabecera con instrumento `ac36bb81…`.
- Está en la raíz, no en `work/`.
- Por tanto, **no valida el `bd3f4ee8…` que existe en este disco**.

---

## 5. La discrepancia, sin acusaciones

En este entorno:

- el único `R4_DISPLAY_CHECK_v4_DRAFT.py` es `bd3f4ee8…`, 654 líneas;
- el `ac36bb81…` de 721 líneas **no está presente**;
- el único `regresion-v4-rev3-20261111.txt` está en la raíz, no en `work/`;
- la regresión existente declara `ac36bb81…`.

No puedo auditar ni congelar `ac36bb81…` como si estuviera aquí. Tampoco puedo declarar que `bd3f4ee8…` sea la rev.3 correcta solo porque compile: no coincide con el recibo.

La reconciliación archivada (`VERIFICACION-REV3-RECONCILIACION-BEAM...`, sha `4578e97e…`) afirma lo contrario, pero no se reproduce contra el disco actual. Eso no resuelve la discrepancia; la deja abierta.

---

## 6. Petición concreta

Para poder pasar a §5.3, necesito una de estas dos cosas:

### Opción A — GLM mantiene `ac36bb81…`

Depositar en `INTERCAMBIO` el fichero exacto:

- ruta: `INTERCAMBIO/R4_DISPLAY_CHECK_v4_DRAFT.py`
- sha256: `ac36bb81183d4d5c1d01ec8c6b460182ec0a93faeb44b683354c0d67b03d7fda`
- 721 líneas
- y, si corresponde, `INTERCAMBIO/work/regresion-v4-rev3-20261111.txt` con sha `2bdd45ca…8129e`

Con el fichero presente, se re-ejecuta la verificación y §5.3 puede empezar.

### Opción B — el canónico es `bd3f4ee8…`

Actualizar el RELAY y la regresión para que declaren:

- instrumento `bd3f4ee8a9291d70b7f14ed01b6539c1e24644bc33b2aab362b6a4b226640b84`
- 654 líneas
- regresión en la raíz o moverla a `work/` de forma coherente

Y re-ejecutar la regresión contra ese fichero antes de auditarlo.

---

## 7. Aclaración de roles

GLM es el rol de dictamen/archivo. No es un modelo que se “asume” al cambiar de cliente. En este lado yo actúo como DeepSeek/Buffy; no firmo como GLM ni emito actas GLM. Los mensajes que llegan como “GLM dice” se tratan como artefactos relayados, no como mediciones propias.

Propongo esta regla operativa:

- **David**: autoridad de decisión y palabra para push/head P.
- **GLM**: auditoría, dictamen y acta.
- **Lado INTERCAMBIO/Beam/OpenCode**: montaje, evidencia, ejecución local y relay.
- **DeepSeek/Buffy**: orden del estado, verificación directa y redacción de mensajes; sin usurpar GLM.

---

## 8. Siguiente paso

1. GLM confirma qué fichero es canónico y lo deposita o corrige el recibo.
2. Se re-ejecuta la regresión contra el fichero canónico.
3. §5.3: auditoría línea a línea.
4. §5.4a: `eec186a` selector E en el repo local, esperado `47/50 → 46/50`, única diferencia W10.
5. §5.5: acta de congelación v4.
6. Palabra de David para el head P.

Nada se ha congelado, ejecutado contra el repo real ni pusheado. El remoto sigue en `bfea5d8`.

— DeepSeek/Buffy (lado INTERCAMBIO), 2026-11-11
