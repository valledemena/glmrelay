# ACTA — CIERRE GLOBAL R4 — merge `e23b47e` — CUSTODIO 2026-11-12

**Custodio:** DeepSeek/Buffy (INTERCAMBIO, Freebuff/Windows)  
**Fecha:** 2026-11-12  
**Anclas:** merge `e23b47ee70bf71e5c9786b7852e42da29ecc04d1` ·
head auditado `24595b13e7b46c4f56b5248ef6156dc547005aa3` ·
base `75366b2fe6395fdee2b7c3229b9da78168b6a512` ·
PR [#36](https://github.com/valledemena/ionosphere-live-3d-android/pull/36) ·
dictamen GLM **FIRME 50/50** ·
CI de main run `43232704433`.

---

## 1. Actuación

Con la palabra de David, se fusionó el PR #36 mediante **merge commit**,
preservando la rama `feat/r4-e-gates` en `24595b1`. Se verificó la topología,
la igualdad de contenido con lo dictaminado, la CI del merge-commit y la
re-ejecución protocolaria del instrumento v5. El slice E queda **CERRADO** y
con él el plan R4 A-E + P.

Evidencia: `work/verify-cierre-e23b47e-20261112.txt`.

## 2. Topología del merge

| Ítem | Resultado |
|---|---|
| `origin/main` | `e23b47ee70bf71e5c9786b7852e42da29ecc04d1` ✓ |
| Merge real | subject «Merge pull request #36 from valledemena/feat/r4-e-gates» · padres `75366b2` (main) + `24595b1` (head auditado) · `2026-11-12T14:00:05Z` |
| **Igualdad de contenido** | `git diff 24595b1..e23b47e` = **VACÍO**; tree IDs idénticos `eb5be2fe7f4bbc4cce23a352277b42fa343cb0c2` ✓ |
| Diff del slice | `75366b2..24595b1` = 5 ficheros **+508/−85** (docs ×3 + tooling E ×2); `app/src/main` = 0 rutas |
| Intocables | workflows/gradle/manifest/FramePacer/DataPanelHost/golden4/`data/` = 0 rutas |
| Histórico | `merge-base --is-ancestor` ✓ para `00ec7cb` (BASE), `75366b2` y `24595b1`; sin reescritura |
| Rama | `feat/r4-e-gates` conservada en `24595b1` |
| APK | sha256 `185c336b9c293e48b79ea121f66d405d705078ba6596c013159469cce50dfc94` — idéntico a `75366b2` |

## 3. PR #36 y CI de main

- **PR #36:** `MERGED`; merge commit `e23b47e…`; head `24595b1…`; base
  `75366b2`; 1 commit (fórmula III).
- **CI main:** run `43232704433`, head `e23b47e…` exacto, event push,
  branch main, **3/3 success**:
  - `lint` — job `131231926164`, `Complete job` success.
  - `assembleDebug` — job `131231926493`, `Complete job` success.
  - `unitTest` — job `131231926536`, `Complete job` success.
- Completado `2026-11-12T14:01:19Z`; sin fallos.

## 4. Instrumento v5

`R4_DISPLAY_CHECK_v5.py` sha256
`ba4332979840d2893bd28e694ca5c8f03e39cc81ad8c149bcd1e6212daa89f00`
— sin cambios.

### 4.1 E sobre el head auditado `24595b1`

**50/50 PASS — VEREDICTO FIRME (slice E).** Evidencia:
`work/r4check-e-24595b1-v5.txt` (sha256 `8115ca0d…6dd66`).

### 4.2 E sobre el merge `e23b47e` (re-ejecución protocolaria)

**48/50 PASS** — S3/S4 FAIL **por diseño**: la ref es el merge commit
(`rev-list count = 0`; padres `75366b2 24595b1`, no un único commit). Todos
los checks de contenido PASS: E0, E1, E2, E3, S1-S2, S5-S10, A, B, C, W, K.
Mismo patrón que las actas post-merge A/B/C/D/P.

### 4.3 P sobre el merge `e23b47e` (constancia)

**44/48 PASS** — S3/S4 por diseño; S6 FAIL porque el diff acumulado ya
incluye `scripts/e1_latency.py` y `scripts/e2_halo.py`, fuera de la whitelist
P; P0 FAIL porque el diff de código del slice P contra el merge es vacío.
**P1 PASS**; todo el contenido A/B/C/W/K sigue verde. El FIRME P es el de su
head `a483f48` / merge `75366b2` (48/48), no se degrada por la entrada de E.

## 5. Tablero global R4

| Slice | Merge | Estado |
|---|---|---|
| A | `810478e` | FIRME, fusionado |
| B | `9550914` | FIRME, fusionado |
| C | `cebd6ef` | FIRME, fusionado |
| D | `bfea5d8` | FIRME, fusionado |
| P | `75366b2` | FIRME, fusionado |
| **E** | **`e23b47e`** | **FIRME 50/50, fusionado** |

**R4 A-E + P: CERRADO.** El medidor R5 queda durable en
`docs/r4/tools/w11-metric.py` de main (sha256 `b3794c49…`).

## 6. Mérito de la falsación

E falsó el programa sobre `eec186a` (E2 **1.74**); la causa raíz `mediump` se
verificó contra fuentes primarias; P corrigió con `precision highp float;` y
su propio FIRME 48/48; E re-cortado midió **5.03 / 1.12**, exactamente lo
predicho por el diagnóstico highp. No se tocó ningún umbral.

## 7. No bloqueantes

- **O3:** ventana 3 del `e1-raw-eec186a`: 29.91 en informe vs 29.90 en aviso
  (serie pre-P, un centésimo, sin efecto en gates).
- **O4:** el aviso 0335 no incluía numstat/tests; GLM los computó
  (+508/−85; 180/33). Corregido en el aviso 0336.
- **O5:** cierre API del run `43222422536` mecánico por cuota; GLM verificó
  CI por HTML a tres niveles. El run de main `43232704433` sí quedó verificado
  por API.

## 8. Cierre

**R4 SLICE E: CERRADO** — head `24595b1` (FIRME 50/50, CI 3/3) → merge
`e23b47e` (árbol idéntico, CI main 3/3) → este acta.

**Programa R4: CERRADO en verificación** (A, B, C, D, P, E). Pendiente del
lado GLM: acta global con su paquete y `SHA256SUMS`; el backlog R5
(forma de bloom, gate DEEP explícito, export de vídeo, O1 doble literal 42)
queda fuera del alcance de R4.

— DeepSeek/Buffy (custodio), 2026-11-12
